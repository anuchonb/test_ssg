-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2026 at 02:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_ssg_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `approvals`
--

CREATE TABLE `approvals` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `total_amount` decimal(12,2) DEFAULT NULL,
  `room_amount` decimal(12,2) DEFAULT NULL,
  `insurance_amount` decimal(12,2) DEFAULT NULL,
  `furniture_amount` decimal(12,2) DEFAULT NULL,
  `contract_date` datetime DEFAULT NULL,
  `transfer_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `approvals`
--

INSERT INTO `approvals` (`id`, `case_id`, `total_amount`, `room_amount`, `insurance_amount`, `furniture_amount`, `contract_date`, `transfer_date`, `note`, `created_at`) VALUES
(1, 1, 3200000.00, 2800000.00, 150000.00, 250000.00, '2026-05-04 10:00:00', '2026-05-20', 'อนุมัติวงเงินรวม 3.2 ล้านบาท', '2026-05-04 03:35:00'),
(2, 2, 5500000.00, 5000000.00, 200000.00, 300000.00, '2026-05-03 14:00:00', '2026-05-25', 'ลูกค้าขอสินเชื่อเพิ่มเฟอร์นิเจอร์', '2026-05-03 07:35:00');

-- --------------------------------------------------------

--
-- Table structure for table `bank_submissions`
--

CREATE TABLE `bank_submissions` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `bank_name` varchar(150) DEFAULT NULL,
  `submit_date` date DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `bank_submissions`
--

INSERT INTO `bank_submissions` (`id`, `case_id`, `bank_name`, `submit_date`, `note`, `created_at`) VALUES
(1, 1, 'ธนาคารกรุงไทย', '2026-05-01', 'ส่งเอกสารครบ ใช้สิทธิ์โครงการ', '2026-05-01 03:35:00'),
(2, 2, 'ธนาคารออมสิน', '2026-05-02', 'ลูกค้าเก่า ใช้สวัสดิการข้าราชการ', '2026-05-02 03:35:00'),
(3, 3, 'ธนาคารอาคารสงเคราะห์', '2026-05-03', 'ยื่นกู้ร่วมกับภรรยา', '2026-05-03 03:35:00'),
(4, 5, 'ธนาคารกรุงเทพ', '2026-05-04', 'พนักงานประจำ เงินเดือนสูง', '2026-05-04 03:35:00');

-- --------------------------------------------------------

--
-- Table structure for table `cases`
--

CREATE TABLE `cases` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `case_date` date DEFAULT NULL,
  `submit_date` date DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `follow_status` varchar(100) DEFAULT NULL,
  `follow_count` int(11) DEFAULT 0,
  `cancel_reason` varchar(255) DEFAULT NULL,
  `owner_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `cases`
--

INSERT INTO `cases` (`id`, `customer_id`, `case_date`, `submit_date`, `status`, `follow_status`, `follow_count`, `cancel_reason`, `owner_id`, `created_at`) VALUES
(1, 1, '2026-04-25', '2026-04-25', 'กำลังติดตาม', 'interested', 3, NULL, 1, '2026-04-25 05:00:00'),
(2, 2, '2026-04-28', '2026-04-28', 'ส่งเคส', 'pending', 1, NULL, 1, '2026-04-28 08:30:00'),
(3, 3, '2026-04-30', '2026-04-30', 'วงเงินไม่ถึง', 'not_qualified', 2, 'รายได้ไม่ถึงเกณฑ์ขั้นต่ำ', 1, '2026-04-30 03:15:00'),
(4, 4, '2026-05-01', '2026-05-01', 'ยกเลิก', 'cancelled', 1, 'ลูกค้าเปลี่ยนใจไปซื้อโครงการอื่น', 2, '2026-05-01 06:45:00'),
(5, 5, '2026-05-02', '2026-05-02', 'กำลังติดตาม', 'high_interest', 4, NULL, 2, '2026-05-02 09:20:00'),
(6, 6, '2026-05-03', '2026-05-03', 'ส่งเคส', 'pending', 0, NULL, 1, '2026-05-03 11:30:00'),
(7, 7, '2026-05-03', '2026-05-03', 'ไม่สนใจ', 'not_interested', 1, 'ลูกค้าต้องการห้องใหญ่กว่านี้', 2, '2026-05-03 14:00:00'),
(8, 8, '2026-05-04', '2026-05-04', 'กำลังติดตาม', 'negotiating', 2, NULL, 1, '2026-05-04 07:10:00');

-- --------------------------------------------------------

--
-- Table structure for table `case_activities`
--

CREATE TABLE `case_activities` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `case_activities`
--

INSERT INTO `case_activities` (`id`, `case_id`, `action`, `user_id`, `created_at`) VALUES
(1, 1, 'Case Created', 1, '2026-04-25 05:00:00'),
(2, 1, 'Follow #1: ติดต่อครั้งแรก', 1, '2026-04-26 05:00:00'),
(3, 1, 'KPI Check: Pass', 3, '2026-04-27 05:00:00'),
(4, 2, 'Case Created', 1, '2026-04-28 08:30:00'),
(5, 2, 'ส่งเอกสารให้ Support', 1, '2026-04-29 08:30:00'),
(6, 3, 'Case Created', 1, '2026-04-30 03:15:00'),
(7, 3, 'KPI Check: Fail - รายได้ไม่ถึง', 3, '2026-05-01 03:15:00'),
(8, 4, 'Case Created', 2, '2026-05-01 06:45:00'),
(9, 5, 'Case Created', 2, '2026-05-02 09:20:00'),
(10, 5, 'Follow #1: สนใจมาก', 2, '2026-05-02 09:20:00'),
(11, NULL, 'User Login: admin@company.com', 6, '2026-05-04 09:14:22'),
(12, NULL, 'User Logout: admin@company.com', 6, '2026-05-04 09:48:26'),
(13, NULL, 'User Login: somsri@company.com', 1, '2026-05-04 09:48:50'),
(14, NULL, 'User Logout: somsri@company.com', 1, '2026-05-04 09:54:26'),
(15, NULL, 'User Login: wichan@company.com', 3, '2026-05-04 10:00:02'),
(16, NULL, 'User Logout: wichan@company.com', 3, '2026-05-04 10:00:22'),
(17, NULL, 'User Login: admin@company.com', 6, '2026-05-04 10:06:04'),
(18, NULL, 'User Logout: admin@company.com (2026-05-04 17:37:43)', 6, '2026-05-04 10:37:43'),
(19, NULL, 'User Login: somsri@company.com', 1, '2026-05-04 11:27:30'),
(20, NULL, 'User Logout: somsri@company.com (2026-05-04 18:37:02)', 1, '2026-05-04 11:37:02'),
(21, NULL, 'User Login: admin@company.com', 6, '2026-05-04 11:37:13'),
(22, NULL, 'User Logout: admin@company.com (2026-05-04 18:49:05)', 6, '2026-05-04 11:49:05'),
(23, NULL, 'User Login: mana@company.com', 4, '2026-05-04 11:49:16'),
(24, NULL, 'User Logout: mana@company.com (2026-05-04 18:52:08)', 4, '2026-05-04 11:52:08'),
(25, NULL, 'User Login: admin@company.com', 6, '2026-05-04 11:52:18'),
(26, NULL, 'User Logout: admin@company.com (2026-05-04 19:31:12)', 6, '2026-05-04 12:31:12'),
(27, NULL, 'User Login: admin@company.com', 6, '2026-05-04 12:31:55'),
(28, 8, 'KPI Check: ผ่าน', 6, '2026-05-04 12:58:14');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `customer_code` varchar(50) DEFAULT NULL,
  `name` varchar(150) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `facebook` varchar(150) DEFAULT NULL,
  `line_id` varchar(150) DEFAULT NULL,
  `page_name` varchar(150) DEFAULT NULL,
  `channel` varchar(100) DEFAULT NULL,
  `grade` varchar(10) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `cashback` decimal(12,2) DEFAULT NULL,
  `living_type` enum('rent','live') DEFAULT NULL,
  `zone` varchar(150) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `work_age_month` int(11) DEFAULT NULL,
  `welfare` varchar(100) DEFAULT NULL,
  `debt_status` enum('have','none') DEFAULT NULL,
  `admin_status` varchar(100) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `customer_code`, `name`, `phone`, `facebook`, `line_id`, `page_name`, `channel`, `grade`, `project_id`, `price`, `cashback`, `living_type`, `zone`, `company_name`, `work_age_month`, `welfare`, `debt_status`, `admin_status`, `created_by`, `created_at`) VALUES
(1, 'CUS202604250001', 'สมชาย ใจดี', '0812345678', 'Somchai Jaidee', 'somchai_j', 'คอนโดดีดี', 'FB', 'A+', 1, 3200000.00, 50000.00, 'live', 'กรุงเทพ-ตะวันออก', 'บริษัท ไทยเทค จำกัด', 48, 'ประกันสังคม', 'none', NULL, 1, '2026-04-25 05:00:00'),
(2, 'CUS202604280001', 'สมหญิง รักดี', '0823456789', 'Somying Rakdee', 'somying_r', 'บ้านสวย', 'TikTok', 'A', 2, 5500000.00, 100000.00, 'rent', 'กรุงเทพ-เหนือ', 'ธนาคารกรุงเทพ', 120, 'กองทุนสำรองเลี้ยงชีพ', 'have', NULL, 1, '2026-04-28 08:30:00'),
(3, 'CUS202604300001', 'วิชัย มั่งมี', '0834567890', 'Wichai Mangmee', 'wichai_m', 'ลงทุนคอนโด', 'Line', 'B', 3, 1800000.00, 30000.00, 'rent', 'ชลบุรี', 'ฟรีแลนซ์', 24, 'ไม่มี', 'have', NULL, 1, '2026-04-30 03:15:00'),
(4, 'CUS202605010001', 'นภา สายลม', '0845678901', 'Napa Sailom', 'napa_s', 'คอนโดสวย', 'FB', 'A', 1, 4200000.00, 80000.00, 'live', 'กรุงเทพ-ใต้', 'บริษัท สยามเทค จำกัด', 36, 'ประกันสังคม', 'none', NULL, 2, '2026-05-01 06:45:00'),
(5, 'CUS202605020001', 'ประสิทธิ์ มั่นคง', '0856789012', 'Prasit Mankong', 'prasit_m', 'บ้านใหม่', 'TikTok', 'A+', 5, 6800000.00, 150000.00, 'live', 'กรุงเทพ-กลาง', 'บริษัท พลังงานไทย จำกัด มหาชน', 60, 'กองทุนสำรองเลี้ยงชีพ', 'none', NULL, 2, '2026-05-02 09:20:00'),
(6, 'CUS202605030001', 'มาลี ดอกไม้', '0867890123', 'Malee Dokmai', 'malee_d', 'สวนคอนโด', 'FB', 'B', 2, 2500000.00, 40000.00, 'live', 'นนทบุรี', 'โรงพยาบาลกรุงเทพ', 24, 'สวัสดิการโรงพยาบาล', 'have', NULL, 1, '2026-05-03 11:30:00'),
(7, 'CUS202605030002', 'ธนา พาณิชย์', '0878901234', 'Thana Panich', 'thana_p', 'ลงทุนคอนโด', 'Line', 'A', 3, 3500000.00, 70000.00, 'rent', 'สมุทรปราการ', 'เจ้าของธุรกิจ', 120, 'ไม่มี', 'have', NULL, 2, '2026-05-03 14:00:00'),
(8, 'CUS202605040001', 'รัตนา แก้วใส', '0889012345', 'Ratana Kaewsai', 'ratana_k', 'คอนโดดีดี', 'FB', 'A+', 4, 4900000.00, 100000.00, 'live', 'กรุงเทพ-ตะวันตก', 'บริษัท โกลบอลเทค จำกัด', 48, 'ประกันสังคม', 'none', NULL, 1, '2026-05-04 07:10:00'),
(9, 'CUS202605040002', 'ภาณุ วิเศษ', '0890123456', 'Panu Wiset', 'panu_w', 'บ้านสวย', 'TikTok', 'B', 1, 2100000.00, 30000.00, 'live', 'ปทุมธานี', 'รับจ้างทั่วไป', 12, 'ไม่มี', 'have', NULL, 2, '2026-05-04 08:00:00'),
(10, 'CUS202605040003', 'กนกวรรณ สดใส', '0901234567', 'Kanokwan Sodsai', 'kanokwan_s', 'ลงทุนคอนโด', 'Line', 'A', 5, 7500000.00, 200000.00, 'rent', 'กรุงเทพ-กลาง', 'บริษัท ปตท. จำกัด มหาชน', 96, 'กองทุนสำรองเลี้ยงชีพ', 'none', NULL, 1, '2026-05-04 08:30:00');

-- --------------------------------------------------------

--
-- Table structure for table `debt_clearings`
--

CREATE TABLE `debt_clearings` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `clear_date` datetime DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `staff_name` varchar(150) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `debt_clearings`
--

INSERT INTO `debt_clearings` (`id`, `case_id`, `clear_date`, `location`, `staff_name`, `note`, `created_at`) VALUES
(1, 2, '2026-05-03 10:00:00', 'ธนาคารกรุงเทพ สาขาสีลม', 'คุณสมชาย ผู้ช่วย', 'ปิดหนี้บัตรเครดิตและสินเชื่อส่วนบุคคล', '2026-05-03 03:35:00');

-- --------------------------------------------------------

--
-- Table structure for table `debt_items`
--

CREATE TABLE `debt_items` (
  `id` int(11) NOT NULL,
  `debt_id` int(11) DEFAULT NULL,
  `detail` varchar(255) DEFAULT NULL,
  `amount` decimal(12,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `debt_items`
--

INSERT INTO `debt_items` (`id`, `debt_id`, `detail`, `amount`) VALUES
(1, 1, 'บัตรเครดิต ธนาคารกรุงเทพ', 150000.00),
(2, 1, 'สินเชื่อส่วนบุคคล', 200000.00),
(3, 1, 'ผ่อนรถยนต์', 350000.00);

-- --------------------------------------------------------

--
-- Table structure for table `document_steps`
--

CREATE TABLE `document_steps` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `doc_status_1` varchar(50) DEFAULT NULL,
  `doc_status_2` varchar(50) DEFAULT NULL,
  `doc_status_3` varchar(50) DEFAULT NULL,
  `bank_name` varchar(150) DEFAULT NULL,
  `bank_account` varchar(100) DEFAULT NULL,
  `precheck_status` varchar(50) DEFAULT NULL,
  `debt_close_status` enum('done','not_done') DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `document_steps`
--

INSERT INTO `document_steps` (`id`, `case_id`, `doc_status_1`, `doc_status_2`, `doc_status_3`, `bank_name`, `bank_account`, `precheck_status`, `debt_close_status`, `note`, `created_at`) VALUES
(1, 1, 'ผ่าน', 'ผ่าน', 'ผ่าน', 'ธนาคารกรุงไทย', '123-456-7890', 'ผ่าน', 'done', 'เอกสารครบถ้วน ส่งธนาคารได้', '2026-04-30 03:35:00'),
(2, 2, 'ผ่าน', 'ผ่าน', 'ไม่ผ่าน', 'ธนาคารออมสิน', '234-567-8901', 'รอดำเนินการ', 'not_done', 'ขาดเอกสารสลิปเงินเดือน', '2026-05-02 03:35:00'),
(3, 5, 'ผ่าน', 'ผ่าน', 'ผ่าน', 'ธนาคารกรุงเทพ', '345-678-9012', 'ผ่าน', 'done', 'เอกสารพร้อม ส่งตรวจสอบ', '2026-05-04 03:35:00');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `file_type` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `case_id`, `file_path`, `file_type`, `created_at`) VALUES
(1, 1, '/uploads/cases/1/slip_salary_01.pdf', 'สลิปเงินเดือน', '2026-04-28 03:35:00'),
(2, 1, '/uploads/cases/1/id_card_01.pdf', 'บัตรประชาชน', '2026-04-28 03:35:00'),
(3, 1, '/uploads/cases/1/house_registration.pdf', 'ทะเบียนบ้าน', '2026-04-29 03:35:00'),
(4, 2, '/uploads/cases/2/id_card.pdf', 'บัตรประชาชน', '2026-05-01 03:35:00'),
(5, 1, '/uploads/cases/1/bank_statement.pdf', 'Statement ย้อนหลัง 6 เดือน', '2026-05-02 03:35:00'),
(6, 5, '/uploads/cases/5/salary_cert.pdf', 'หนังสือรับรองเงินเดือน', '2026-05-04 03:35:00');

-- --------------------------------------------------------

--
-- Table structure for table `follow_logs`
--

CREATE TABLE `follow_logs` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `step` int(11) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `follow_logs`
--

INSERT INTO `follow_logs` (`id`, `case_id`, `step`, `status`, `note`, `created_at`) VALUES
(1, 1, 1, 'interested', 'ติดต่อครั้งแรก สนใจห้องแบบ 1 bedroom', '2026-04-26 05:00:00'),
(2, 1, 2, 'document_submitted', 'ส่งเอกสารเรียบร้อย รอตรวจสอบ', '2026-04-27 05:00:00'),
(3, 1, 3, 'negotiating', 'ต่อรองราคา ขอส่วนลดเพิ่ม', '2026-04-28 05:00:00'),
(4, 2, 1, 'pending', 'รอลูกค้าส่งเอกสารเพิ่มเติม', '2026-04-29 05:00:00'),
(5, 3, 1, 'not_qualified', 'แจ้งลูกค้าว่าวงเงินไม่ถึง', '2026-05-01 03:15:00'),
(6, 3, 2, 'cancelled', 'ลูกค้ายืนยันไม่สนใจต่อ', '2026-05-02 03:15:00'),
(7, 5, 1, 'high_interest', 'ลูกค้าสนใจมาก ต้องการจองทันที', '2026-05-02 09:20:00'),
(8, 5, 2, 'document_submitted', 'ส่งเอกสารครบ รออนุมัติ', '2026-05-03 09:20:00'),
(9, 5, 3, 'bank_submitted', 'ส่งธนาคารแล้ว รอผล', '2026-05-04 09:20:00'),
(10, 5, 4, 'waiting_approval', 'รอผลอนุมัติจากธนาคาร', '2026-05-04 09:30:00'),
(11, 7, 1, 'not_interested', 'ลูกค้าต้องการห้อง 2 bedroom แต่โครงการไม่มี', '2026-05-03 14:00:00'),
(12, 8, 1, 'interested', 'สนใจห้องริมสระว่ายน้ำ', '2026-05-04 07:10:00'),
(13, 8, 2, 'site_visit', 'นัดดูห้องจริงวันที่ 6 พ.ค.', '2026-05-04 07:15:00'),
(22, 8, 3, 'interested', 'Test', '2026-05-04 12:54:50'),
(23, 8, 4, 'cancelled', '', '2026-05-04 12:55:10');

-- --------------------------------------------------------

--
-- Table structure for table `inspections`
--

CREATE TABLE `inspections` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `round` int(11) DEFAULT NULL,
  `inspect_date` datetime DEFAULT NULL,
  `status` enum('pass','fail') DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `inspections`
--

INSERT INTO `inspections` (`id`, `case_id`, `round`, `inspect_date`, `status`, `note`, `created_at`) VALUES
(1, 1, 1, '2026-05-02 09:00:00', 'pass', 'ตรวจห้องครั้งที่ 1: สภาพห้องดี ไม่มี defect', '2026-05-02 02:00:00'),
(2, 1, 2, '2026-05-03 14:00:00', 'pass', 'ตรวจห้องครั้งที่ 2: เก็บงานเรียบร้อย พร้อมโอน', '2026-05-03 07:00:00'),
(3, 2, 1, '2026-05-04 10:00:00', 'fail', 'ตรวจห้องครั้งที่ 1: พบรอยร้าวที่ผนัง ต้องแก้ไข', '2026-05-04 03:35:00');

-- --------------------------------------------------------

--
-- Table structure for table `kpi_checks`
--

CREATE TABLE `kpi_checks` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `checker_id` int(11) DEFAULT NULL,
  `result` enum('pass','fail') DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `kpi_checks`
--

INSERT INTO `kpi_checks` (`id`, `case_id`, `checker_id`, `result`, `reason`, `created_at`) VALUES
(1, 1, 3, 'pass', 'คุณภาพการสนทนาดี ให้ข้อมูลครบถ้วน', '2026-04-27 05:00:00'),
(2, 2, 3, 'pass', 'การให้บริการเป็นมืออาชีพ', '2026-04-30 05:00:00'),
(3, 3, 3, 'fail', 'ไม่ตรวจสอบคุณสมบัติลูกค้าก่อนส่งเคส', '2026-05-01 03:15:00'),
(4, 4, 3, 'fail', 'ไม่ตามลูกค้าภายใน 24 ชม.', '2026-05-02 06:45:00'),
(5, 8, 6, 'pass', '', '2026-05-04 12:58:13');

-- --------------------------------------------------------

--
-- Table structure for table `master_dropdowns`
--

CREATE TABLE `master_dropdowns` (
  `id` int(11) NOT NULL,
  `type` varchar(100) DEFAULT NULL,
  `value` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `master_dropdowns`
--

INSERT INTO `master_dropdowns` (`id`, `type`, `value`, `is_active`, `created_at`) VALUES
(1, 'channel', 'FB', 1, '2026-05-04 12:03:47'),
(2, 'channel', 'TikTok', 1, '2026-05-04 12:03:47'),
(3, 'channel', 'Line', 1, '2026-05-04 12:03:47'),
(4, 'channel', 'Website', 1, '2026-05-04 12:03:47'),
(5, 'channel', 'Walk-in', 1, '2026-05-04 12:03:47'),
(6, 'channel', 'Referral', 1, '2026-05-04 12:03:47'),
(7, 'zone', 'กรุงเทพ-กลาง', 1, '2026-05-04 12:03:47'),
(8, 'zone', 'กรุงเทพ-เหนือ', 1, '2026-05-04 12:03:47'),
(9, 'zone', 'กรุงเทพ-ใต้', 1, '2026-05-04 12:03:47'),
(10, 'zone', 'กรุงเทพ-ตะวันออก', 1, '2026-05-04 12:03:47'),
(11, 'zone', 'กรุงเทพ-ตะวันตก', 1, '2026-05-04 12:03:47'),
(12, 'zone', 'นนทบุรี', 1, '2026-05-04 12:03:47'),
(13, 'zone', 'ปทุมธานี', 1, '2026-05-04 12:03:47'),
(14, 'zone', 'สมุทรปราการ', 1, '2026-05-04 12:03:47'),
(15, 'zone', 'ชลบุรี', 1, '2026-05-04 12:03:47'),
(16, 'zone', 'เชียงใหม่', 1, '2026-05-04 12:03:47'),
(17, 'zone', 'ภูเก็ต', 1, '2026-05-04 12:03:47'),
(18, 'welfare', 'ประกันสังคม', 1, '2026-05-04 12:03:47'),
(19, 'welfare', 'กองทุนสำรองเลี้ยงชีพ', 1, '2026-05-04 12:03:47'),
(20, 'welfare', 'สวัสดิการโรงพยาบาล', 1, '2026-05-04 12:03:47'),
(21, 'welfare', 'ไม่มี', 1, '2026-05-04 12:03:47'),
(22, 'case_status', 'ส่งเคส', 1, '2026-05-04 12:03:47'),
(23, 'case_status', 'กำลังติดตาม', 1, '2026-05-04 12:03:47'),
(24, 'case_status', 'ยกเลิก', 1, '2026-05-04 12:03:47'),
(25, 'case_status', 'ไม่สนใจ', 1, '2026-05-04 12:03:47'),
(26, 'case_status', 'วงเงินไม่ถึง', 1, '2026-05-04 12:03:47'),
(27, 'case_status', 'อนุมัติ', 1, '2026-05-04 12:03:47'),
(28, 'case_status', 'ปฏิเสธ', 1, '2026-05-04 12:03:47'),
(29, 'follow_status', 'interested', 1, '2026-05-04 12:03:47'),
(30, 'follow_status', 'pending', 1, '2026-05-04 12:03:47'),
(31, 'follow_status', 'document_submitted', 1, '2026-05-04 12:03:47'),
(32, 'follow_status', 'negotiating', 1, '2026-05-04 12:03:47'),
(33, 'follow_status', 'cancelled', 1, '2026-05-04 12:03:47'),
(34, 'follow_status', 'not_qualified', 1, '2026-05-04 12:03:47'),
(35, 'follow_status', 'not_interested', 1, '2026-05-04 12:03:47'),
(36, 'follow_status', 'high_interest', 1, '2026-05-04 12:03:47'),
(37, 'follow_status', 'bank_submitted', 1, '2026-05-04 12:03:47'),
(38, 'follow_status', 'waiting_approval', 1, '2026-05-04 12:03:47'),
(39, 'follow_status', 'approved', 1, '2026-05-04 12:03:47'),
(40, 'follow_status', 'transferred', 1, '2026-05-04 12:03:47'),
(41, 'kpi_reason', 'ไม่ตาม', 1, '2026-05-04 12:03:47'),
(42, 'kpi_reason', 'ลูกค้าไม่ตอบ', 1, '2026-05-04 12:03:47'),
(43, 'kpi_reason', 'ติดบูโร', 1, '2026-05-04 12:03:47'),
(44, 'kpi_reason', 'อายุงานไม่ถึง', 1, '2026-05-04 12:03:47'),
(45, 'kpi_reason', 'รายได้ไม่ถึง', 1, '2026-05-04 12:03:47'),
(46, 'kpi_reason', 'เปลี่ยนใจ', 1, '2026-05-04 12:03:47'),
(47, 'kpi_reason', 'เอกสารไม่ครบ', 1, '2026-05-04 12:03:47'),
(48, 'kpi_reason', 'หนี้เยอะ', 1, '2026-05-04 12:03:47'),
(49, 'bank', 'ธนาคารกรุงเทพ', 1, '2026-05-04 12:03:47'),
(50, 'bank', 'ธนาคารกสิกรไทย', 1, '2026-05-04 12:03:47'),
(51, 'bank', 'ธนาคารกรุงไทย', 1, '2026-05-04 12:03:47'),
(52, 'bank', 'ธนาคารไทยพาณิชย์', 1, '2026-05-04 12:03:47'),
(53, 'bank', 'ธนาคารกรุงศรีอยุธยา', 1, '2026-05-04 12:03:47'),
(54, 'bank', 'ธนาคารออมสิน', 1, '2026-05-04 12:03:47'),
(55, 'bank', 'ธนาคารอาคารสงเคราะห์', 1, '2026-05-04 12:03:47'),
(56, 'bank', 'ธนาคารทหารไทยธนชาต', 1, '2026-05-04 12:03:47'),
(57, 'bank', 'ธนาคารยูโอบี', 1, '2026-05-04 12:03:47'),
(58, 'channel', 'Test', 1, '2026-05-04 12:03:47');

-- --------------------------------------------------------

--
-- Table structure for table `mortgages`
--

CREATE TABLE `mortgages` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `mortgage_date` date DEFAULT NULL,
  `bank_name` varchar(150) DEFAULT NULL,
  `account_name` varchar(150) DEFAULT NULL,
  `account_number` varchar(100) DEFAULT NULL,
  `approved_amount` decimal(12,2) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `mortgages`
--

INSERT INTO `mortgages` (`id`, `case_id`, `mortgage_date`, `bank_name`, `account_name`, `account_number`, `approved_amount`, `created_at`) VALUES
(1, 1, '2026-05-15', 'ธนาคารกรุงไทย', 'สมชาย ใจดี', '123-456-7890', 2800000.00, '2026-05-04 03:35:00'),
(2, 2, '2026-05-20', 'ธนาคารออมสิน', 'สมหญิง รักดี', '234-567-8901', 5000000.00, '2026-05-03 07:35:00');

-- --------------------------------------------------------

--
-- Table structure for table `pre_approvals`
--

CREATE TABLE `pre_approvals` (
  `id` int(11) NOT NULL,
  `case_id` int(11) DEFAULT NULL,
  `status` enum('processing','approved','rejected') DEFAULT NULL,
  `approved_amount` decimal(12,2) DEFAULT NULL,
  `note` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `pre_approvals`
--

INSERT INTO `pre_approvals` (`id`, `case_id`, `status`, `approved_amount`, `note`, `created_at`) VALUES
(1, 1, 'approved', 3200000.00, 'Pre-approve ผ่าน วงเงิน 3.2 ล้าน', '2026-04-29 03:35:00'),
(2, 2, 'approved', 5500000.00, 'อนุมัติวงเงินกู้ซื้อ', '2026-05-02 03:35:00'),
(3, 3, 'rejected', 0.00, 'รายได้ไม่เข้าเกณฑ์', '2026-05-01 03:35:00'),
(4, 5, 'processing', NULL, 'กำลังตรวจสอบเอกสาร', '2026-05-04 03:35:00');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` decimal(12,2) DEFAULT NULL,
  `zone` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `name`, `price`, `zone`, `created_at`) VALUES
(1, 'The Metro สุขุมวิท', 3500000.00, 'กรุงเทพ-ตะวันออก', '2026-01-01 00:00:00'),
(2, 'Supalai พหลโยธิน', 5200000.00, 'กรุงเทพ-เหนือ', '2026-01-01 00:00:00'),
(3, 'Lumpini พระราม 2', 1900000.00, 'สมุทรปราการ', '2026-01-01 00:00:00'),
(4, 'Ideo รัชโยธิน', 4500000.00, 'กรุงเทพ-กลาง', '2026-02-01 00:00:00'),
(5, 'Ashton จุฬา', 7000000.00, 'กรุงเทพ-กลาง', '2026-02-01 00:00:00'),
(6, 'Condo U รังสิต', 1500000.00, 'ปทุมธานี', '2026-03-01 00:00:00'),
(7, 'Niche Mono บางนา', 2200000.00, 'สมุทรปราการ', '2026-03-01 00:00:00'),
(8, 'The Tree เตาปูน', 3800000.00, 'กรุงเทพ-เหนือ', '2026-04-01 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` enum('admin_page','kpi','support','admin') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'คุณสมศรี Admin Page', 'somsri@company.com', '123456', 'admin_page', '2026-01-01 00:00:00'),
(2, 'คุณสมหมาย Admin Page 2', 'sommai@company.com', '123456', 'admin_page', '2026-01-01 00:00:00'),
(3, 'คุณวิชาญ KPI', 'wichan@company.com', '123456', 'kpi', '2026-01-01 00:00:00'),
(4, 'คุณมานะ Support', 'mana@company.com', '123456', 'support', '2026-01-01 00:00:00'),
(5, 'คุณสุพจน์ Support 2', 'supoj@company.com', '123456', 'support', '2026-01-01 00:00:00'),
(6, 'Admin ใหญ่', 'admin@company.com', 'admin123', 'admin', '2026-01-01 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approvals`
--
ALTER TABLE `approvals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `bank_submissions`
--
ALTER TABLE `bank_submissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `cases`
--
ALTER TABLE `cases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `owner_id` (`owner_id`);

--
-- Indexes for table `case_activities`
--
ALTER TABLE `case_activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `customer_code` (`customer_code`),
  ADD KEY `project_id` (`project_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `debt_clearings`
--
ALTER TABLE `debt_clearings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `debt_items`
--
ALTER TABLE `debt_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `debt_id` (`debt_id`);

--
-- Indexes for table `document_steps`
--
ALTER TABLE `document_steps`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `follow_logs`
--
ALTER TABLE `follow_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `inspections`
--
ALTER TABLE `inspections`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `kpi_checks`
--
ALTER TABLE `kpi_checks`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`),
  ADD KEY `checker_id` (`checker_id`);

--
-- Indexes for table `master_dropdowns`
--
ALTER TABLE `master_dropdowns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mortgages`
--
ALTER TABLE `mortgages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `pre_approvals`
--
ALTER TABLE `pre_approvals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `case_id` (`case_id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approvals`
--
ALTER TABLE `approvals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `bank_submissions`
--
ALTER TABLE `bank_submissions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cases`
--
ALTER TABLE `cases`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `case_activities`
--
ALTER TABLE `case_activities`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `debt_clearings`
--
ALTER TABLE `debt_clearings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `debt_items`
--
ALTER TABLE `debt_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `document_steps`
--
ALTER TABLE `document_steps`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `follow_logs`
--
ALTER TABLE `follow_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `inspections`
--
ALTER TABLE `inspections`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `kpi_checks`
--
ALTER TABLE `kpi_checks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `master_dropdowns`
--
ALTER TABLE `master_dropdowns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=59;

--
-- AUTO_INCREMENT for table `mortgages`
--
ALTER TABLE `mortgages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `pre_approvals`
--
ALTER TABLE `pre_approvals`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `approvals`
--
ALTER TABLE `approvals`
  ADD CONSTRAINT `approvals_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`);

--
-- Constraints for table `bank_submissions`
--
ALTER TABLE `bank_submissions`
  ADD CONSTRAINT `bank_submissions_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`);

--
-- Constraints for table `cases`
--
ALTER TABLE `cases`
  ADD CONSTRAINT `cases_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  ADD CONSTRAINT `cases_ibfk_2` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `case_activities`
--
ALTER TABLE `case_activities`
  ADD CONSTRAINT `case_activities_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`),
  ADD CONSTRAINT `case_activities_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `customers_ibfk_1` FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`),
  ADD CONSTRAINT `customers_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `debt_clearings`
--
ALTER TABLE `debt_clearings`
  ADD CONSTRAINT `debt_clearings_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`);

--
-- Constraints for table `debt_items`
--
ALTER TABLE `debt_items`
  ADD CONSTRAINT `debt_items_ibfk_1` FOREIGN KEY (`debt_id`) REFERENCES `debt_clearings` (`id`);

--
-- Constraints for table `document_steps`
--
ALTER TABLE `document_steps`
  ADD CONSTRAINT `document_steps_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`);

--
-- Constraints for table `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `files_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`);

--
-- Constraints for table `follow_logs`
--
ALTER TABLE `follow_logs`
  ADD CONSTRAINT `follow_logs_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`);

--
-- Constraints for table `inspections`
--
ALTER TABLE `inspections`
  ADD CONSTRAINT `inspections_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`);

--
-- Constraints for table `kpi_checks`
--
ALTER TABLE `kpi_checks`
  ADD CONSTRAINT `kpi_checks_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`),
  ADD CONSTRAINT `kpi_checks_ibfk_2` FOREIGN KEY (`checker_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `mortgages`
--
ALTER TABLE `mortgages`
  ADD CONSTRAINT `mortgages_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`);

--
-- Constraints for table `pre_approvals`
--
ALTER TABLE `pre_approvals`
  ADD CONSTRAINT `pre_approvals_ibfk_1` FOREIGN KEY (`case_id`) REFERENCES `cases` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
